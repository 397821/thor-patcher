//Note: Currently the patcher does not minify the code before pack.
//You will have to do it manually if you wish to reduce the footprint.

require('test.js');
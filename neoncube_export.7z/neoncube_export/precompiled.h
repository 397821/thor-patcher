#include <stdio.h>

#include <windows.h>
#include <tchar.h>

#include <shlwapi.h>

/*############################################################################
##  NEONCUBE - RAGNAROK ONLINE PATCH CLIENT (GNU General Public License)
##
##  http://openkore.sourceforge.net/neoncube
##  (c) 2005 Ansell "Cliffe" Cruz (Cliffe@xeronhosting.com)
##
##############################################################################*/

#include <unrar/dll.hpp>

BOOL ExtractRAR(LPTSTR fname, LPCTSTR fpath);
void PostRarError(int Error,char *ArcName);
